package alumno;

public class Alumno {
	static int contCodigos;
	private int codigo;
	private String nombre;
	String[] modulos;
	
	Alumno(){
		codigo=contCodigos++;
		setNombre("No introducido");
		modulos = new String[0];
	}
	Alumno(String nom, int cod){
		this.setCodigo(cod);
		this.setNombre(nom);
	}
	public int getCodigo() {
		return codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setCodigo(int cod) {
		this.codigo = cod;
	}
	public void setNombre(String nom) {
		this.nombre = nom;
	}
	public String toString() {
		return "Nombre: " + nombre + "\nCódigo: " + codigo;
	}
	
	
}
